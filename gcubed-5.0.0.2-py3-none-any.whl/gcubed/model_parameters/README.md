# Model Parameter Defaults

This directory contains helpers for generating model parameter files.

## Default Value Shapes

Default parameter values are represented according to their shape:

- Scalar defaults stay as Python constants in `gcubed.model_parameters`.
- Sector-ordered vector defaults live in packaged CSV files under
  `default_data/`.

Scalar constants include values such as `TECHNOLOGY_ADVANCEMENT_RATE`,
`TECHNOLOGY_CATCHUP_RATE`, `PHI_Y`, and `PHI_Z`. These values do not vary by
sector order or mapping label.

## Sector Parameter Defaults

Sector-ordered defaults are stored in:

```text
default_data/sector_parameter_defaults.csv
```

The CSV schema is:

```text
parameter,mapping_label,sector,value
```

The `mapping_label` column uses the same values as
`GTAPCommodityMappingColumnLabel` in model `configuration.csv` files, such as
`standard_12`, `standard_15`, and `semiconductors_7`.

The `sector` column preserves the ordering of each vector. It is sorted by the
loader before values are returned.

## Loading Package Data

`gcubed.model_parameters.defaults` loads the CSV with `importlib.resources`.
This keeps default data available when `gcubed` is installed as a Python
package rather than run from a repository checkout.

Use:

```python
sector_parameter_default("PHI", model_configuration.gtap_commodity_mapping_column_label)
```

to retrieve a list of values for one parameter and mapping label.

## Baseline Setup Policy

`gcubed.model_parameters.default_policy` centralizes label-driven default
selection for baseline data generation. The policy records the active GTAP
country label, GTAP commodity label, and Ember generation label where relevant.

`generate_baseline_data_files_and_user_parameters()` uses this policy before it
generates user parameters, technology advancement rates, technology catchup
rates, technology gaps, and autonomous energy efficiency improvements. Current
scalar defaults remain global Python constants, but the policy is the place to
add label-specific scalar or regional overrides when tests show that they are
needed.

## Adding Defaults

To add a new mapping label or parameter vector:

1. Add rows to `default_data/sector_parameter_defaults.csv`.
2. Use the exact `GTAPCommodityMappingColumnLabel` value from the model
   configuration file.
3. Add one row per ordered sector/member value.
4. Keep scalar defaults in Python unless they genuinely need label-specific
   overrides.
5. Run the model parameter default tests.

Recommended checks:

```bash
pytest tests/generic/test_model_parameters
pytest tests/generic/test_setup/test_model_configuration_mapping_labels.py
```
